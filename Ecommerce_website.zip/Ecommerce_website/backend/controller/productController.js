exports.getAllProducts = (req,res) =>{

    res.status(200).json({message:"Route is Working fine"})
}